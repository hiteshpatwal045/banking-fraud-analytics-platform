from datetime import datetime

from pipeline.extract import extract_data
from pipeline.validators.customer_validator import validate_customers
from pipeline.validators.loan_validator import validate_loans
from pipeline.rejected_handler import save_rejected_records, REJECTED_DIR
from pipeline.transform import transform_data
from pipeline.load import load_data

def run_pipeline() -> None:
  """Execute the complete pipeline"""

  print("Starting Banking Data Pipeline....")

  run_id = datetime.now().strftime("RUN_%Y%m%d_%H%M%S")

  print("Step 1. Extracting Data....")
  customers, loans = extract_data()

  print("Step 2. Validating Customers....")
  valid_customers, rejected_customers = validate_customers(customers)

  print("Step 3. Validating Loans....")
  valid_customer_ids = set(valid_customers["customer_id"])
  valid_loans, rejected_loans = validate_loans(loans, valid_customer_ids)

  print("Step 4. Saving Rejected Records....")
  save_rejected_records(rejected_customers, rejected_loans, run_id)

  print("Step 5. Transforming Data....")
  valid_customers, valid_loans = transform_data(valid_customers, valid_loans)

  print("Step 6. Loading Data into MySQL....")
  load_data(valid_customers, valid_loans)

  print("\nPipeline Summary")
  print("==========================")
  print("Customers received :", len(customers))
  print("Customers loaded   :", len(valid_customers))
  print("Customers rejected :", len(rejected_customers))
  print("Loans received     :", len(loans))
  print("Loans loaded       :", len(valid_loans))
  print("Loans rejected     :", len(rejected_loans))

  print("\nPipeline completed successfully")
  print(f"Rejected folder : {REJECTED_DIR}")


if __name__ == "__main__":
  run_pipeline()